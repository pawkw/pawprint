<?php

function pawprint_customize_register( $wp_customize ) {

    $wp_customize->get_setting('blogname') -> transport = 'postMessage';

    $wp_customize->selective_refresh->add_partial('blogname', array(
        // 'settings' => array('blogname')
        'selector' => '.pawprint-site-name',
        'container_inclusive' => false,
        'render_callback' => function() {
            bloginfo( 'name' );
        }
    ));

    /* ========== General settings ========== */

    $wp_customize->add_section('pawprint_general_options', array(
        'title' => esc_html__( 'General Options', 'pawprint' ),
        'description' => esc_html__( 'Change the general options.', 'pawprint' ),
        'priority' => '30'
    ));

    $wp_customize->add_setting('pawprint_accent_color', array(
        'default' => '#20ddae',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage'
    ));

    $wp_customize->add_control( 
        new WP_Customize_Color_Control( 
        $wp_customize, 
        'pawprint_accent_color', 
        array(
            'label'      => __( 'Accent Color', 'pawprint' ),
            'section'    => 'pawprint_general_options',
            'settings'   => 'pawprint_accent_color',
        ) ) 
    );


    /* ========== Footer settings ========== */

    $wp_customize->selective_refresh->add_partial('pawprint-footer-partial', array(
        'settings' => array('pawprint_footer_bg', 'pawprint_footer_layout'),
        'selector' => '#footer',
        'container_inclusive' => false,
        'render_callback' => function() {
            get_template_part( 'template-parts/footer/widgets' );
            get_template_part( 'template-parts/footer/info' );
        }
    ));

    $wp_customize->add_section('pawprint_footer_options', array(
        'title' => esc_html__( 'Footer Options', 'pawprint' ),
        'description' => esc_html__( 'Change the footer options.', 'pawprint' ),
        'priority' => '30'
    ));

    $wp_customize->add_setting('pawprint_footer_bg', array(
        'default' => 'dark',
        'sanitize_callback' => 'pawprint_sanitize_footer_bg',
        'transport' => 'postMessage'
    ));

    $wp_customize->add_control('pawprint_footer_bg', array(
        'type' => 'select',
        'label' => esc_html__( 'Footer background', 'pawprint' ),
        'choices' => array(
            'dark' => esc_html__( 'Dark', 'pawprint' ),
            'light' => esc_html__( 'Light', 'pawprint' )
        ),
        'section' => 'pawprint_footer_options'
    ));

    $wp_customize->add_setting('pawprint_footer_layout', array(
        'default' => '3,3,3,3',
        'sanitize_callback' => 'sanitize_text_field',
        'validate_callback' => 'pawprint_validate_footer_layout',
        'transport' => 'postMessage'
    ));

    $wp_customize->add_control('pawprint_footer_layout', array(
        'type' => 'text',
        'label' => esc_html__( 'Footer Layout', 'pawprint' ),
        'section' => 'pawprint_footer_options',
        'description' => 'List the width of each column (out of 12) seperated by commas. Ex. Three columns with a wide middle would be 3,6,3.'
    ));

    $wp_customize->add_setting('pawprint_site_info', array(
        'default' => '',
        'sanitize_callback' => 'pawprint_sanitize_site_info',
        'transport' => 'postMessage'
    ));

    $wp_customize->add_control('pawprint_site_info', array(
        'type' => 'text',
        'label' => esc_html__( 'Site info', 'pawprint' ),
        'section' => 'pawprint_footer_options'
    ));
}

add_action( 'customize_register', 'pawprint_customize_register', 10, 1 );

function pawprint_sanitize_site_info( $input ) {
    $allowed = array( 'a' => array(
        'href' => array(),
        'title' => array()
    ));
    return wp_kses( $input, $allowed );
}

function pawprint_sanitize_footer_bg( $input ) {
    $valid = array('light', 'dark');
    if(in_array( $input, $valid, true)) {
        return $input;
    }
    return 'dark';
}

function pawprint_validate_footer_layout( $validity, $input ) {
    if(!preg_match('/^([1-9]|1[012])(,([1-9]|1[012]))*$/', $input)) {
        $validity->add('invalid_footer_layout', esc_html__( 'Invalid layout.', 'pawprint' ));
    }
    return $validity;
}