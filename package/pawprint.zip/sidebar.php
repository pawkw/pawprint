<aside role="complementary" class="pawprint-sidebar">
    <?php
        dynamic_sidebar( 'primary-sidebar' ); 
    ?>
</aside>