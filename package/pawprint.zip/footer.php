        </div> <!-- pawprint-content -->
        <footer role="contentinfo" id="footer">
        <?php
            get_template_part( 'template-parts/footer/widgets' );
            get_template_part( 'template-parts/footer/info' );
        ?>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>

