<?php

require_once('lib/post_decorations.php');
require_once('lib/enqueue_assets.php');