<p>
    <?php
        echo apply_filters( 'pawprint_no_posts_text', esc_html__('Sorry, no posts matched your criteria.', 'pawprint') );
    ?>
</p>